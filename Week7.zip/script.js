import { createApp } from 'vue'
import App from './App.vue'
import { ref } from 'vue'




console.log('Hello world this is my Vue project')



createApp(App).mount('#app')

Vue.component('name',{Text})
Vue.component('message',{Text})

