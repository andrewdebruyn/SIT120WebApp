<script setup>
import {ref} from 'vue'


const count = ref(0)
const red =ref(0)
const greet =ref(0)
const firstName = ref('')
const password = ref('')
const picked = ref('')
const isActive =ref(false)
const message = ref('')
const formsubmitted =ref(false)

</script>

<template>
  <h1>Hello Vue 3</h1>
  <button @click="count++">Count is: {{ count }}</button>
  
  <h2 v-if="count<5">Less than 5</h2>
  <h1 v-else>5 or higher</h1>

  <form>
  <div class=form>
  <label>Enter your name </label>
 <input v-model='firstName'>
 
 <label> Enter your password  </label>
 <input v-model='password'>
 <h1> Hello {{ firstName }} </h1>
 <h2> Your password is: {{ password }} </h2>

<input type="radio" id="E" value="Economy class" v-model="picked">
<label for="E">Economy class</label>
<br>
<input type="radio" id="B" value="Business class" v-model="picked">
<label for="B">Business class</label>
<br>
<span>Picked: {{ picked }}</span>


 </div>
  </form>
 


 

<form>
<div class=newform>

<h1>User details</h1>
<h3>Name {{firstName}}</h3>
<h3>Password {{password}}</h3>
<h3>Travel class : {{picked}}</h3>
<h3 v-if="formsubmitted">SUBMITTED</h3>
</div>
</form> 

<button @click="formsubmitted =!formsubmitted">SUBMIT</button>
 <p> </p>
 


</template>

<style scoped>
button {
  font-weight: bold;
}
</style>