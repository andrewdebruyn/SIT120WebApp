import { createApp } from 'vue'
import App from './App.vue'
import { ref } from 'vue'



//animals[] = {"dog,"cat","rat"}
console.log('Hello world')



createApp(App).mount('#app')

Vue.component('name',{Text})
